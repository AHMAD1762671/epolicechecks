<div class="row">
    <div class="col-sm-12 text-center">
        <img src="<?= base_url('site-assets') ?>/images/Logo_epolicecheckfinal-02.png" style="height: 200px; width: 343px;">
    </div>
</div>
<div class="row ">
    <div class="col-sm-2">

    </div>

    <div class="col-sm-8 text-dark  bg-white">

        <h5 class="text-dark">Select one of the following</h5>
        <hr>

    </div>
    <div class="col-sm-1  ">

    </div>
</div>
<div class="row" style="margin-bottom: 70px;">
    <div class="col-sm-2">

    </div>

    <div class="col-sm-4 text-dark bg-white text-center abc " style=" border: 1px solid #d1d4db;

         border-bottom: 4px solid #c1d72f;">
        <a href="<?= base_url()?>name-based-check/canada">
            <img src="<?= base_url('site-assets') ?>/images/Canadian.gif" class="mt-5 mb-2 " style="height: 139px; width: i35px;  ">
            <h5 class="mt-3">CANADA</h5>
            <p>I am currently residing in Canada </p>
        </a>

    </div>
    <div class="col-sm-4 text-dark  bg-white text-center abc" style="margin-left: 10px; border: 1px solid #d1d4db;

         border-bottom: 4px solid #c1d72f;">
        <a href="<?= base_url()?>name-based-check/foreigner">
            <img src="<?= base_url('site-assets') ?>/images/map.png" class="mt-5 mb-2 " style="height: 139px; width: 135px;  ">
            <h5 class="mt-3">INTERNATIONAL</h5>
            <p>I am currently residing in a foreign country </p>
        </a>
    </div>
    <div class="col-sm-2  ">

    </div>
</div>